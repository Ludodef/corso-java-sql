package eserciziopattern.document;

public class ExcelDocument extends Document {
	

	

	public ExcelDocument(String nome, double size) {
		super(nome, size);
		
	}

	@Override
	public void open() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void save() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void view() {
		// TODO Auto-generated method stub
		
	}

}
