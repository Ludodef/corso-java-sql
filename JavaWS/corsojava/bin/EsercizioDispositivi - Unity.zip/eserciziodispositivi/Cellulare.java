package eserciziodispositivi;

public class Cellulare extends Telefono  {

	private String sim;
	private String sistemaOperativo; 
	
	public Cellulare(boolean stato,String colore, String nome, boolean silenzioso, String tipo,String sim, String sistemaOperativo) {
		super(stato,colore, nome, silenzioso, tipo);
		this.sim = sim;
		this.sistemaOperativo = sistemaOperativo;
	}
	

	@Override
	public void mostraInfo() {
		
		super.mostraInfo();
		System.out.println("Sim -> " + sim +
							"\nSistema operativo -> " + sistemaOperativo);
	}


	public String getSim() {
		return sim;
	}


	public void setSim(String sim) {
		this.sim = sim;
	}


	public String getSistemaOperativo() {
		return sistemaOperativo;
	}


	public void setSistemaOperativo(String sistemaOperativo) {
		this.sistemaOperativo = sistemaOperativo;
	}
	
	
	
	

}
