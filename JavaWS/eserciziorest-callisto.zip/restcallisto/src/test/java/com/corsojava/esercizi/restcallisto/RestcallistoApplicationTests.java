package com.corsojava.esercizi.restcallisto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestcallistoApplicationTests {

	@Test
	void contextLoads() {
	}

}
